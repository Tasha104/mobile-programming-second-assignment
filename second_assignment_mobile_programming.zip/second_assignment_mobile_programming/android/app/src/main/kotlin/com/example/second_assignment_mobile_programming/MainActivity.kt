package com.example.second_assignment_mobile_programming

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
